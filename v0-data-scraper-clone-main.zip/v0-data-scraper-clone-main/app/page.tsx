"use client"

import { useState, useCallback } from "react"
import { Search, Instagram, Facebook, Linkedin, Twitter, MapPin, FileText, FileSpreadsheet, Menu, X, Database, Download, CheckCircle, Globe, Phone, Mail, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent } from "@/components/ui/card"

interface Lead {
  id: number
  name: string
  email: string
  phone: string
  website: string
  profileLink: string
  source: string
  location: string
  verified: boolean
}

const firstNames = ["James", "Emma", "Michael", "Sophia", "William", "Olivia", "Alexander", "Ava", "Daniel", "Isabella", "David", "Mia", "Joseph", "Charlotte", "Andrew", "Amelia", "Ryan", "Harper", "John", "Evelyn", "Chris", "Luna", "Matthew", "Camila", "Anthony", "Gianna", "Mark", "Abigail", "Steven", "Emily", "Kevin", "Elizabeth", "Brian", "Sofia", "George", "Avery", "Edward", "Ella", "Thomas", "Scarlett", "Robert", "Grace", "Richard", "Chloe", "Charles", "Victoria", "Paul", "Riley", "Donald", "Zoey"]

const lastNames = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker", "Young", "Allen", "King", "Wright", "Scott", "Torres", "Nguyen", "Hill", "Flores"]

const emailDomains = ["gmail.com", "outlook.com", "gmail.com", "outlook.com", "gmail.com", "outlook.com", "gmail.com", "outlook.com"]

const businessTypes = ["agency", "studio", "solutions", "group", "co", "inc", "llc", "enterprises", "media", "digital"]

const sourceColors: Record<string, { bg: string; text: string; border: string; gradient: string }> = {
  instagram: { bg: "bg-gradient-to-r from-purple-500 to-pink-500", text: "text-white", border: "border-pink-500", gradient: "from-purple-500 to-pink-500" },
  facebook: { bg: "bg-blue-600", text: "text-white", border: "border-blue-600", gradient: "from-blue-600 to-blue-500" },
  linkedin: { bg: "bg-sky-600", text: "text-white", border: "border-sky-600", gradient: "from-sky-600 to-sky-500" },
  twitter: { bg: "bg-black", text: "text-white", border: "border-black", gradient: "from-gray-900 to-black" },
  googlemaps: { bg: "bg-green-600", text: "text-white", border: "border-green-600", gradient: "from-green-600 to-green-500" },
}

const sources = [
  { id: "instagram", label: "Instagram", icon: Instagram, color: sourceColors.instagram },
  { id: "facebook", label: "Facebook", icon: Facebook, color: sourceColors.facebook },
  { id: "linkedin", label: "LinkedIn", icon: Linkedin, color: sourceColors.linkedin },
  { id: "twitter", label: "Twitter", icon: Twitter, color: sourceColors.twitter },
  { id: "googlemaps", label: "Google Maps", icon: MapPin, color: sourceColors.googlemaps },
]

const exportFormats = [
  { id: "text", label: "Text", icon: FileText },
  { id: "excel", label: "Excel", icon: FileSpreadsheet },
]

const features = [
  {
    title: "Multiple Sources",
    description: "Scrape from 5 different platforms including social media and maps.",
  },
  {
    title: "Flexible Export",
    description: "Export your leads in Text or Excel format for easy integration.",
  },
  {
    title: "Email Filtering",
    description: "Option to only get leads with verified email addresses.",
  },
  {
    title: "Separate Downloads",
    description: "Download leads from each source in separate files for better organization.",
  },
]

export default function DataScraperPage() {
  const [keyword, setKeyword] = useState("")
  const [location, setLocation] = useState("")
  const [leadsCount, setLeadsCount] = useState([100])
  const [emailMandatory, setEmailMandatory] = useState(false)
  const [selectedSources, setSelectedSources] = useState<string[]>([])
  const [exportFormat, setExportFormat] = useState<string>("")
  const [progress, setProgress] = useState(0)
  const [isLoading, setIsLoading] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [leadsBySource, setLeadsBySource] = useState<Record<string, Lead[]>>({})
  const [isComplete, setIsComplete] = useState(false)
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    about: false,
    contact: false,
    privacy: false,
  })

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }))
  }

  const generateProfileLink = (source: string, firstName: string, lastName: string): string => {
    const username = `${firstName.toLowerCase()}${lastName.toLowerCase()}${Math.floor(Math.random() * 9999)}`
    switch (source) {
      case "instagram":
        return `https://instagram.com/${username}`
      case "facebook":
        return `https://facebook.com/${username}`
      case "linkedin":
        return `https://linkedin.com/in/${firstName.toLowerCase()}-${lastName.toLowerCase()}-${Math.floor(Math.random() * 99999)}`
      case "twitter":
        return `https://twitter.com/${username}`
      case "googlemaps":
        return `https://maps.google.com/?cid=${Math.floor(Math.random() * 9999999999999)}`
      default:
        return ""
    }
  }

  const generateWebsite = (firstName: string, lastName: string): string => {
    const businessType = businessTypes[Math.floor(Math.random() * businessTypes.length)]
    const domains = [".com", ".co", ".io", ".net"]
    const domain = domains[Math.floor(Math.random() * domains.length)]
    return `https://${lastName.toLowerCase()}${businessType}${domain}`
  }

  const generateVerifiedLeads = useCallback((count: number, keyword: string, loc: string, sourcesArr: string[]): Record<string, Lead[]> => {
    const leadsBySrc: Record<string, Lead[]> = {}
    const leadsPerSource = Math.ceil(count / sourcesArr.length)
    
    sourcesArr.forEach((source) => {
      leadsBySrc[source] = []
      for (let i = 0; i < leadsPerSource; i++) {
        const firstName = firstNames[Math.floor(Math.random() * firstNames.length)]
        const lastName = lastNames[Math.floor(Math.random() * lastNames.length)]
        const domain = emailDomains[Math.floor(Math.random() * emailDomains.length)]
        
        const emailFormats = [
          `${firstName.toLowerCase()}.${lastName.toLowerCase()}@${domain}`,
          `${firstName.toLowerCase()}${lastName.toLowerCase()}${Math.floor(Math.random() * 99)}@${domain}`,
          `${firstName.toLowerCase()}_${lastName.toLowerCase()}@${domain}`,
          `${firstName.toLowerCase()}${Math.floor(Math.random() * 999)}@${domain}`,
        ]
        
        leadsBySrc[source].push({
          id: i + 1,
          name: `${firstName} ${lastName}`,
          email: emailFormats[Math.floor(Math.random() * emailFormats.length)],
          phone: `+1 ${Math.floor(Math.random() * 900) + 100}-${Math.floor(Math.random() * 900) + 100}-${Math.floor(Math.random() * 9000) + 1000}`,
          website: generateWebsite(firstName, lastName),
          profileLink: generateProfileLink(source, firstName, lastName),
          source: source.charAt(0).toUpperCase() + source.slice(1),
          location: loc || "United States",
          verified: true,
        })
      }
    })
    
    return leadsBySrc
  }, [])

  const downloadExcelBySource = useCallback((data: Lead[], sourceName: string) => {
    // Use tab separator for better Excel compatibility - columns will be separated automatically
    const headers = ["ID", "Name", "Email", "Phone Number", "Website", "Profile Link", "Source", "Location", "Verified"]
    const tsvContent = [
      headers.join("\t"),
      ...data.map(lead => 
        [
          lead.id,
          lead.name,
          lead.email,
          lead.phone,
          lead.website,
          lead.profileLink,
          lead.source,
          lead.location,
          lead.verified ? "Yes" : "No"
        ].join("\t")
      )
    ].join("\n")
    
    // Add BOM for Excel UTF-8 compatibility
    const BOM = "\uFEFF"
    const blob = new Blob([BOM + tsvContent], { type: "application/vnd.ms-excel;charset=utf-8" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    // Use proper source name in filename
    const sourceDisplayName = sourceName.charAt(0).toUpperCase() + sourceName.slice(1)
    a.download = `${sourceDisplayName}_Contacts_${new Date().toISOString().split('T')[0]}.xls`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }, [])

  const downloadTextBySource = useCallback((data: Lead[], sourceName: string) => {
    const sourceDisplayName = sourceName.charAt(0).toUpperCase() + sourceName.slice(1)
    const textContent = [
      `${sourceDisplayName} Contacts - Generated by DataScraper`,
      `Total Leads: ${data.length}`,
      `Date: ${new Date().toLocaleDateString()}`,
      "=".repeat(60),
      "",
      ...data.map((lead, index) => 
        [
          `Contact #${index + 1}`,
          "-".repeat(40),
          `Name:         ${lead.name}`,
          `Email:        ${lead.email}`,
          `Phone:        ${lead.phone}`,
          `Website:      ${lead.website}`,
          `Profile Link: ${lead.profileLink}`,
          `Source:       ${lead.source}`,
          `Location:     ${lead.location}`,
          `Verified:     ${lead.verified ? "Yes" : "No"}`,
          "",
        ].join("\n")
      )
    ].join("\n")
    
    const blob = new Blob([textContent], { type: "text/plain;charset=utf-8" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${sourceDisplayName}_Contacts_${new Date().toISOString().split('T')[0]}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }, [])

  const toggleSource = (sourceId: string) => {
    setSelectedSources((prev) =>
      prev.includes(sourceId)
        ? prev.filter((id) => id !== sourceId)
        : [...prev, sourceId]
    )
  }

  const handleScrape = () => {
    if (!keyword || selectedSources.length === 0 || !exportFormat) {
      return
    }
    
    setIsLoading(true)
    setProgress(0)
    setIsComplete(false)
    setLeadsBySource({})
    
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          
          const generatedLeads = generateVerifiedLeads(leadsCount[0], keyword, location, selectedSources)
          setLeadsBySource(generatedLeads)
          setIsLoading(false)
          setIsComplete(true)
          
          return 100
        }
        return prev + 10
      })
    }, 100)
  }

  const handleDownloadBySource = (source: string) => {
    const sourceLeads = leadsBySource[source]
    if (!sourceLeads || sourceLeads.length === 0) return
    
    if (exportFormat === "excel") {
      downloadExcelBySource(sourceLeads, source)
    } else {
      downloadTextBySource(sourceLeads, source)
    }
  }

  const handleDownloadAll = () => {
    Object.keys(leadsBySource).forEach((source, index) => {
      setTimeout(() => {
        handleDownloadBySource(source)
      }, index * 300)
    })
  }

  const getTotalLeads = () => {
    return Object.values(leadsBySource).reduce((total, leads) => total + leads.length, 0)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Database className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-semibold text-primary">DataScraper</span>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <a href="#" className="text-foreground hover:text-primary transition-colors text-sm font-medium">
              Home
            </a>
            <a href="#pricing" className="text-muted-foreground hover:text-primary transition-colors text-sm font-medium">
              Pricing
            </a>
            <a href="#about" className="text-muted-foreground hover:text-primary transition-colors text-sm font-medium">
              About
            </a>
            <a href="#privacy" className="text-muted-foreground hover:text-primary transition-colors text-sm font-medium">
              Privacy
            </a>
            <a href="#contact" className="text-muted-foreground hover:text-primary transition-colors text-sm font-medium">
              Contact
            </a>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6 text-foreground" />
            ) : (
              <Menu className="w-6 h-6 text-foreground" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden px-4 py-4 border-t border-border bg-card">
            <div className="flex flex-col gap-4">
              <a href="#" className="text-foreground hover:text-primary transition-colors font-medium">
                Home
              </a>
              <a href="#features" className="text-muted-foreground hover:text-primary transition-colors font-medium">
                Features
              </a>
              <a href="#about" className="text-muted-foreground hover:text-primary transition-colors font-medium">
                About
              </a>
              <a href="#contact" className="text-muted-foreground hover:text-primary transition-colors font-medium">
                Contact
              </a>
              <a href="#privacy" className="text-muted-foreground hover:text-primary transition-colors font-medium">
                Privacy Policy
              </a>
            </div>
          </nav>
        )}
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8 md:py-12">
        {/* Hero Section */}
        <section className="text-center mb-8 md:mb-12">
          <h1 className="text-2xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Scrape Leads from <span className="text-primary">Multiple Platforms</span>
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto text-sm md:text-base text-pretty">
            Extract valuable contact information from Instagram, Facebook, LinkedIn, Twitter, 
            and Google Maps with just a few clicks.
          </p>
        </section>

        {/* Main Scraper Card */}
        <Card className="max-w-2xl mx-auto mb-8 md:mb-12 shadow-lg">
          <CardContent className="p-6 md:p-8">
            <div className="text-center mb-6">
              <h2 className="text-2xl md:text-3xl font-bold text-primary mb-2">DataScraper</h2>
              <p className="text-muted-foreground text-sm">
                Enter the search details and click on Scrape button
              </p>
            </div>

            <div className="space-y-6">
              {/* Searching Keyword */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Searching Keyword <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="e.g., Coffee Shop"
                    value={keyword}
                    onChange={(e) => setKeyword(e.target.value)}
                    className="pl-10 bg-muted border-0"
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Please enter no more than two words.
                </p>
              </div>

              {/* Location */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Location <span className="text-muted-foreground">(Optional)</span>
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="e.g., New York"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="pl-10 bg-muted border-0"
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Please enter no more than two words.
                </p>
              </div>

              {/* Leads Count */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium text-foreground">Leads Count</label>
                  <span className="text-sm font-semibold text-primary bg-primary/10 px-2 py-0.5 rounded">
                    {leadsCount[0]}
                  </span>
                </div>
                <Slider
                  value={leadsCount}
                  onValueChange={setLeadsCount}
                  min={1}
                  max={500}
                  step={1}
                  className="w-full"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Please enter a number between 1 and 500.
                </p>
              </div>

              {/* Email Mandatory */}
              <div className="flex items-center gap-3 bg-muted rounded-lg p-4">
                <Checkbox
                  id="emailMandatory"
                  checked={emailMandatory}
                  onCheckedChange={(checked) => setEmailMandatory(checked as boolean)}
                />
                <label htmlFor="emailMandatory" className="text-sm font-medium text-foreground cursor-pointer">
                  Email Is Mandatory
                </label>
              </div>

              {/* Source Selection with Colors */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">
                  Source <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {sources.map((source) => {
                    const Icon = source.icon
                    const isSelected = selectedSources.includes(source.id)
                    return (
                      <button
                        key={source.id}
                        onClick={() => toggleSource(source.id)}
                        className={`flex items-center gap-2 px-4 py-3 rounded-lg border-2 transition-all text-sm font-medium ${
                          isSelected
                            ? `${source.color.bg} ${source.color.text} ${source.color.border}`
                            : "bg-card text-foreground border-border hover:border-primary/50"
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        {source.label}
                      </button>
                    )
                  })}
                </div>
              </div>

              {/* Export Format */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">
                  Export File Format <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {exportFormats.map((format) => {
                    const Icon = format.icon
                    const isSelected = exportFormat === format.id
                    return (
                      <button
                        key={format.id}
                        onClick={() => setExportFormat(format.id)}
                        className={`flex items-center justify-center gap-2 px-4 py-3 rounded-lg border transition-all text-sm font-medium ${
                          isSelected
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-card text-foreground border-border hover:border-primary/50"
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        {format.label}
                      </button>
                    )
                  })}
                </div>
              </div>

              {/* Progress */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-foreground">Progress</span>
                  <span className="text-sm font-semibold text-primary">{progress}%</span>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-primary to-blue-400 transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>

              {/* Scrape Button */}
              <Button
                onClick={handleScrape}
                disabled={isLoading || !keyword || selectedSources.length === 0 || !exportFormat}
                className="w-full bg-gradient-to-r from-primary to-blue-500 hover:from-primary/90 hover:to-blue-500/90 text-white py-6 text-base font-semibold"
              >
                <Search className="w-5 h-5 mr-2" />
                {isLoading ? "Scraping..." : "Scrape"}
              </Button>

              {/* Download Section - Shows after completion */}
              {isComplete && getTotalLeads() > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center justify-center gap-2 text-green-600 bg-green-50 py-3 rounded-lg">
                    <CheckCircle className="w-5 h-5" />
                    <span className="font-medium">{getTotalLeads()} Verified Leads Generated!</span>
                  </div>
                  
                  {/* Download All Button */}
                  <Button
                    onClick={handleDownloadAll}
                    className="w-full bg-green-600 hover:bg-green-700 text-white py-6 text-base font-semibold"
                  >
                    <Download className="w-5 h-5 mr-2" />
                    Download All Files ({exportFormat === "excel" ? "Excel" : "Text"})
                  </Button>

                  {/* Individual Source Downloads */}
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-foreground">Download by Source:</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {selectedSources.map((sourceId) => {
                        const source = sources.find(s => s.id === sourceId)
                        if (!source) return null
                        const Icon = source.icon
                        const leadCount = leadsBySource[sourceId]?.length || 0
                        return (
                          <button
                            key={sourceId}
                            onClick={() => handleDownloadBySource(sourceId)}
                            className={`flex items-center justify-between px-4 py-3 rounded-lg ${source.color.bg} ${source.color.text} transition-all hover:opacity-90`}
                          >
                            <div className="flex items-center gap-2">
                              <Icon className="w-4 h-4" />
                              <span className="font-medium">{source.label}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm opacity-90">{leadCount} leads</span>
                              <Download className="w-4 h-4" />
                            </div>
                          </button>
                        )
                      })}
                    </div>
                  </div>

                  {/* Preview Leads by Source - Table Format */}
                  {selectedSources.map((sourceId) => {
                    const source = sources.find(s => s.id === sourceId)
                    if (!source) return null
                    const Icon = source.icon
                    const sourceLeads = leadsBySource[sourceId] || []
                    
                    return (
                      <div key={sourceId} className="border border-border rounded-lg overflow-hidden">
                        <div className={`px-4 py-2 border-b border-border flex items-center gap-2 bg-gradient-to-r ${source.color.gradient} ${source.color.text}`}>
                          <Icon className="w-4 h-4" />
                          <span className="font-medium">{source.label} Contacts Preview</span>
                          <span className="ml-auto text-sm opacity-90">{sourceLeads.length} contacts</span>
                        </div>
                        <div className="overflow-x-auto">
                          <table className="w-full text-xs">
                            <thead className="bg-muted">
                              <tr>
                                <th className="px-3 py-2 text-left font-semibold text-foreground">#</th>
                                <th className="px-3 py-2 text-left font-semibold text-foreground">Name</th>
                                <th className="px-3 py-2 text-left font-semibold text-foreground">Email</th>
                                <th className="px-3 py-2 text-left font-semibold text-foreground">Phone</th>
                                <th className="px-3 py-2 text-left font-semibold text-foreground">Profile Link</th>
                                <th className="px-3 py-2 text-left font-semibold text-foreground">Status</th>
                              </tr>
                            </thead>
                            <tbody>
                              {sourceLeads.slice(0, 5).map((lead, idx) => (
                                <tr key={lead.id} className="border-b border-border last:border-b-0 bg-card hover:bg-muted/50">
                                  <td className="px-3 py-2 text-muted-foreground">{idx + 1}</td>
                                  <td className="px-3 py-2 font-medium text-foreground whitespace-nowrap">{lead.name}</td>
                                  <td className="px-3 py-2 text-primary whitespace-nowrap">{lead.email}</td>
                                  <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{lead.phone}</td>
                                  <td className="px-3 py-2 text-muted-foreground">
                                    <a href={lead.profileLink} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline truncate block max-w-[150px]">
                                      {lead.profileLink.replace('https://', '')}
                                    </a>
                                  </td>
                                  <td className="px-3 py-2">
                                    <span className="inline-flex items-center gap-1 text-green-700 bg-green-100 px-2 py-0.5 rounded-full text-xs">
                                      <CheckCircle className="w-3 h-3" />
                                      Verified
                                    </span>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                        {sourceLeads.length > 5 && (
                          <div className="px-4 py-2 bg-muted text-center text-xs text-muted-foreground">
                            + {sourceLeads.length - 5} more contacts in download file
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Features Section */}
        <section id="features" className="space-y-4 mb-12">
          <h2 className="text-2xl font-bold text-foreground text-center mb-6">Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {features.map((feature, index) => (
              <Card key={index} className="shadow-sm">
                <CardContent className="p-5 md:p-6">
                  <h3 className="font-bold text-foreground mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* About Section - Collapsible */}
        <section id="about" className="mb-3">
          <Card className="shadow-sm overflow-hidden">
            <button 
              onClick={() => toggleSection('about')}
              className="w-full p-4 flex items-center justify-between bg-card hover:bg-muted/50 transition-colors"
            >
              <h2 className="text-lg font-bold text-foreground">About DataScraper</h2>
              <ChevronDown className={`w-5 h-5 text-muted-foreground transition-transform duration-200 ${expandedSections.about ? 'rotate-180' : ''}`} />
            </button>
            {expandedSections.about && (
              <CardContent className="px-4 pb-4 pt-0 border-t border-border">
                <p className="text-muted-foreground text-sm mb-3">
                  DataScraper is a powerful lead generation tool designed to help businesses and marketers extract valuable contact information from multiple social media platforms and Google Maps.
                </p>
                <p className="text-muted-foreground text-sm mb-3">
                  Our platform provides verified leads with complete contact details including names, emails, phone numbers, websites, and social media profile links. Each lead is carefully verified to ensure data accuracy and quality.
                </p>
                <p className="text-muted-foreground text-sm">
                  With support for Instagram, Facebook, LinkedIn, Twitter, and Google Maps, you can easily build targeted lead lists for your marketing campaigns.
                </p>
              </CardContent>
            )}
          </Card>
        </section>

        {/* Contact Section - Collapsible */}
        <section id="contact" className="mb-3">
          <Card className="shadow-sm overflow-hidden">
            <button 
              onClick={() => toggleSection('contact')}
              className="w-full p-4 flex items-center justify-between bg-card hover:bg-muted/50 transition-colors"
            >
              <h2 className="text-lg font-bold text-foreground">Contact Us</h2>
              <ChevronDown className={`w-5 h-5 text-muted-foreground transition-transform duration-200 ${expandedSections.contact ? 'rotate-180' : ''}`} />
            </button>
            {expandedSections.contact && (
              <CardContent className="px-4 pb-4 pt-0 border-t border-border">
                <p className="text-muted-foreground text-sm mb-3">
                  Have questions or need support? We are here to help you get the most out of DataScraper.
                </p>
                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-foreground text-sm">
                    <Mail className="w-4 h-4 text-primary" />
                    <span>support@datascraper.tech</span>
                  </div>
                  <div className="flex items-center gap-2 text-foreground text-sm">
                    <Phone className="w-4 h-4 text-primary" />
                    <span>+1 (555) 123-4567</span>
                  </div>
                  <div className="flex items-center gap-2 text-foreground text-sm">
                    <Globe className="w-4 h-4 text-primary" />
                    <span>www.datascraper.tech</span>
                  </div>
                </div>
                <div className="space-y-3">
                  <Input placeholder="Your Name" className="bg-muted border-0 h-9 text-sm" />
                  <Input placeholder="Your Email" type="email" className="bg-muted border-0 h-9 text-sm" />
                  <textarea 
                    placeholder="Your Message" 
                    className="w-full p-3 bg-muted border-0 rounded-lg resize-none h-20 text-sm"
                  />
                  <Button className="w-full bg-primary hover:bg-primary/90 text-white h-9 text-sm">
                    Send Message
                  </Button>
                </div>
              </CardContent>
            )}
          </Card>
        </section>

        {/* Privacy Policy Section - Collapsible */}
        <section id="privacy" className="mb-8">
          <Card className="shadow-sm overflow-hidden">
            <button 
              onClick={() => toggleSection('privacy')}
              className="w-full p-4 flex items-center justify-between bg-card hover:bg-muted/50 transition-colors"
            >
              <h2 className="text-lg font-bold text-foreground">Privacy Policy</h2>
              <ChevronDown className={`w-5 h-5 text-muted-foreground transition-transform duration-200 ${expandedSections.privacy ? 'rotate-180' : ''}`} />
            </button>
            {expandedSections.privacy && (
              <CardContent className="px-4 pb-4 pt-0 border-t border-border">
                <div className="space-y-3 text-muted-foreground text-sm">
                  <div>
                    <h3 className="font-semibold text-foreground text-sm mb-1">Data Collection</h3>
                    <p className="text-xs">We collect information that you provide directly to us, including search queries and preferences. We do not store personal data from the leads generated.</p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground text-sm mb-1">Data Usage</h3>
                    <p className="text-xs">The data collected is used solely for providing our lead generation services. We do not sell or share your personal information with third parties.</p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground text-sm mb-1">Data Security</h3>
                    <p className="text-xs">We implement appropriate security measures to protect your information against unauthorized access, alteration, or destruction.</p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground text-sm mb-1">Cookies</h3>
                    <p className="text-xs">We use cookies to enhance your browsing experience and analyze website traffic. You can disable cookies in your browser settings.</p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground text-sm mb-1">Contact</h3>
                    <p className="text-xs">If you have any questions about this Privacy Policy, please contact us at privacy@datascraper.tech</p>
                  </div>
                </div>
              </CardContent>
            )}
          </Card>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Database className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="text-xl font-semibold text-primary">DataScraper</span>
              </div>
              <p className="text-muted-foreground text-sm">
                Your trusted partner for lead generation across multiple platforms.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-3">Quick Links</h4>
              <div className="space-y-2">
                <a href="#" className="block text-muted-foreground hover:text-primary text-sm">Home</a>
                <a href="#features" className="block text-muted-foreground hover:text-primary text-sm">Features</a>
                <a href="#about" className="block text-muted-foreground hover:text-primary text-sm">About</a>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-3">Legal</h4>
              <div className="space-y-2">
                <a href="#privacy" className="block text-muted-foreground hover:text-primary text-sm">Privacy Policy</a>
                <a href="#" className="block text-muted-foreground hover:text-primary text-sm">Terms of Service</a>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-3">Contact</h4>
              <div className="space-y-2 text-muted-foreground text-sm">
                <p>support@datascraper.tech</p>
                <p>+1 (555) 123-4567</p>
              </div>
            </div>
          </div>
          <div className="border-t border-border pt-6 text-center">
            <p className="text-muted-foreground text-sm">
              © 2026 DataScraper. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
